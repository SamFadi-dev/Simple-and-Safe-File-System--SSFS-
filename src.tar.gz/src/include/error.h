#ifndef ERROR_H
#define ERROR_H

extern const int vdisk_ENODISK ;
extern const int vdisk_EACCESS ;
extern const int vdisk_ENOEXIST;
extern const int vdisk_EEXCEED ;
extern const int vdisk_ESECTOR ;
extern const int fs_EWRITE     ;
extern const int fs_ESYNC      ;
extern const int fs_EREAD      ;
#endif
